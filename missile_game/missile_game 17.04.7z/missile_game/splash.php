<div id="splash">

	<div id="box">
	
		<div id="titlegame" >
				MISSILE GAME
		</div>
		
		<div id="menu">
			
			<button type="button" id="btnPlay"> > PLAY </button>
			
		</div>
					
	</div>
	
	
	<script>	
		$('#btnPlay').click( function() {
			$('#splash').addClass("fadeOutBox");
			$('#game').addClass("blurAnimationStart");
			});
	
		
	</script>

			
				
</div>