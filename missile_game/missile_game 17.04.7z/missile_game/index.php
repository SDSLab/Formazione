<?php include 'header.php'; ?>
	<body>

		<div id="main">
			
			<?php include 'splash.php'; ?>
			
			<?php include 'game.php'; ?>
		
		
		
		</div>
		
		
	</body>
</html>