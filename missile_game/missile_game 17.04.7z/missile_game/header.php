<html> 

<head>
  <link href="css/css/main.css" rel="stylesheet" type="text/css">
  <link href="css/css/game.css" rel="stylesheet" type="text/css">
  <link href="css/css/animation.css" rel="stylesheet" type="text/css">
  <link href="css/css/splash.css" rel="stylesheet" type="text/css">
  <link href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.css" rel="stylesheet">
  
  
  <script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
 </head>
